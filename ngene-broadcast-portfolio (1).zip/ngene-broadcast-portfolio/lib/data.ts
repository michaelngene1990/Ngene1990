// All copy on the site is sourced from this file, rewritten from the
// candidate's CV and LinkedIn profile in the site's own editorial voice.

export const profile = {
  name: "Michael Ngene",
  fullName: "Michael Onyedikachi Ngene",
  role: "Broadcast Scriptwriter & Content Producer",
  tagline: "I turn the day's chaos into a script the newsroom can broadcast.",
  location: "Lagos, Nigeria",
  email: "mickeyngene@gmail.com",
  phone: "+234 806 121 8506",
  linkedin: "https://www.linkedin.com/in/michaelngene90",
  currentEmployer: "BBC News",
};

export const stats = [
  { value: "10+", label: "years in broadcast newsrooms" },
  { value: "4", label: "African nations covered, 2023 elections" },
  { value: "6", label: "newsrooms, one byline" },
  { value: "1", label: "senator's removal, traced to a segment he produced" },
];

export const about = {
  paragraphs: [
    "Michael writes for the moment a story goes live — the script a presenter can read at pace, the sub-edit that survives a breaking-news rewrite, the package that still lands after the satellite feed drops out. That discipline was built on air, not in a classroom: he started as an on-air personality in Enugu and has since scripted, produced, or sub-edited news for six broadcasters across Nigeria and the wider continent.",
    "At News Central, he ran the editorial engine behind Breakfast Central, Africa's most-watched morning programme during his tenure — sourcing guests, writing rundowns, and shaping the segment that led to a sitting senator's removal from office. At BBC News, that same instinct for a clean, broadcast-ready script now serves audiences across TV, digital, and partner platforms.",
    "He holds an HND in Mass Communication from the Institute of Management and Technology, Enugu, and trained in broadcast ethics and news production with BBC Media Action.",
  ],
};

export type Experience = {
  id: string;
  period: string;
  duration: string;
  role: string;
  org: string;
  location: string;
  current?: boolean;
  summary: string;
  bullets: string[];
};

export const experience: Experience[] = [
  {
    id: "bbc",
    period: "APR 2024 — PRESENT",
    duration: "2 yrs 6 mos",
    role: "Broadcast Journalist",
    org: "BBC News",
    location: "Lagos, Nigeria",
    current: true,
    summary:
      "Pitches, writes, and produces news scripts and digital video for BBC's TV, digital, and partner platforms under strict editorial compliance.",
    bullets: [
      "Compile and write news stories and digital video scripts cleared to BBC editorial and safeguarding standards before distribution across digital and partner platforms.",
      "Report and produce on location, balancing field constraints against a tight weekly broadcast deadline.",
      "Rough-cut packages and brief shoot editors to bring footage up to broadcast standard.",
      "Remote-produce reporters and correspondents on shoot: scripting, sub-editing, and sourcing stories and guests from the field.",
      "Shape digital and social publishing strategy to extend the reach of each story beyond the original broadcast.",
    ],
  },
  {
    id: "newscentral",
    period: "JAN 2021 — MAR 2024",
    duration: "3 yrs 3 mos",
    role: "Producer / Researcher",
    org: "News Central Television",
    location: "Lagos, Nigeria",
    summary:
      "Ran the editorial desk for Breakfast Central, News Central's flagship morning programme, from research through script to air.",
    bullets: [
      "Owned the show's editorial pipeline: researched stories, booked guests, and wrote and proofread the daily rundown and scripts.",
      "Directed 2023 general-election coverage across Sierra Leone, Zimbabwe, Liberia, and Nigeria, from pre-election reporting through election day to post-election analysis.",
      "Grew Breakfast Central into Africa's most-watched morning programme during his tenure, while building a source network spanning political and economic analysts.",
      "Produced the segment in which Senator Ishaku Abbo's on-air revelation about the Senate's leadership exposed internal disputes and led to his removal from office.",
      "Fact-checked scripts and briefed the graphics team to keep every segment ethically sound and visually broadcast-ready.",
    ],
  },
  {
    id: "cameraboy",
    period: "APR 2020 — JAN 2021",
    duration: "10 mos",
    role: "Production Director / Content Analyst",
    org: "CameraBoy Multimedia",
    location: "Lagos, Nigeria",
    summary:
      "Directed script and content strategy for commercial clients, translating briefs into production-ready creative.",
    bullets: [
      "Assessed client briefs and scripts for feasibility, then set the creative direction the production team executed against.",
      "Led advert production for Orange Drugs, Medplus Pharmaceuticals, and Blenco Stores, acting as the primary client contact throughout.",
      "Planned production against client budgets, timelines, and available resources.",
      "Trained the production unit as part of repositioning CameraBoy's output for a broader client base — recognised staff of the month four times.",
    ],
  },
  {
    id: "ogene",
    period: "AUG 2017 — APR 2020",
    duration: "2 yrs 9 mos",
    role: "Head of Programmes",
    org: "Ogene FM, Awka",
    location: "Anambra State, Nigeria",
    summary:
      "Set the station's on-air content strategy and hosted its flagship morning show.",
    bullets: [
      "Wrote, edited, and produced scripts, audio reports, and inserts across the station's news output.",
      "Repositioned the station's programme slate to serve a wider range of audiences, while keeping every show compliant with NBC regulation.",
      "Hosted the Morning Wake-Up show, the station's daily entry point for listeners.",
      "Ogene FM was named Anambra State's most-listened-to radio station by the Football Writers Association during his tenure as Head of Programmes.",
    ],
  },
  {
    id: "dream",
    period: "2014 — 2017",
    duration: "3 yrs",
    role: "On-Air Personality / Presenter-Producer",
    org: "Dream 92.5 FM, Enugu",
    location: "Enugu, Nigeria",
    summary:
      "Started his broadcast career writing, editing, and presenting the station's flagship talk programme.",
    bullets: [
      "Developed content and produced Peoples Forum, editing audio packages in Adobe Audition.",
      "Staffed the situation room during Nigeria's 2015 general election, monitoring and reporting through election day.",
      "Wrote, researched, and delivered news segments as the station's content producer and newscaster.",
      "Hosted one of the state's most-listened-to midnight programmes and was recognised as Enugu State's Best Aspiring Radio Presenter.",
    ],
  },
];

export type Project = {
  id: string;
  tag: string;
  title: string;
  outlet: string;
  description: string;
  detail: string;
};

export const projects: Project[] = [
  {
    id: "elections-2023",
    tag: "SEGMENT 01",
    title: "2023 Pan-African Election Desk",
    outlet: "News Central Television",
    description:
      "Directed script and research for live election coverage spanning four countries, from pre-election build-up to post-election fallout.",
    detail:
      "Nigeria, Sierra Leone, Zimbabwe, and Liberia — one editorial desk tracking every stage of the vote, feeding scripts and rundowns to anchors on air in real time.",
  },
  {
    id: "breakfast-central",
    tag: "SEGMENT 02",
    title: "Breakfast Central",
    outlet: "News Central Television",
    description:
      "Wrote and produced the daily rundown for the programme that became Africa's most-watched morning show during his tenure.",
    detail:
      "Editorial ownership end to end: guest sourcing, script writing, fact-checking, and the graphics brief that put each story to air.",
  },
  {
    id: "abbo-revelation",
    tag: "SEGMENT 03",
    title: "The Segment That Changed the Senate",
    outlet: "News Central Television",
    description:
      "Produced the on-air interview in which Senator Ishaku Abbo revealed internal Senate leadership disputes.",
    detail:
      "The story that followed his broadcast contributed to the senator's removal from office — a case study in what a well-produced segment can set in motion.",
  },
];

export type SkillGroup = {
  title: string;
  skills: string[];
};

export const skillGroups: SkillGroup[] = [
  {
    title: "Writing & Editorial",
    skills: [
      "Scriptwriting",
      "News writing & sub-editing",
      "Editorial judgement",
      "Fact-checking",
      "Rundown production",
    ],
  },
  {
    title: "Production",
    skills: [
      "TV production",
      "Field & on-location producing",
      "Rough-cut package editing",
      "Audio editing (Adobe Audition)",
      "Graphics & VFX liaison",
    ],
  },
  {
    title: "Field & Research",
    skills: [
      "Interviewing",
      "Investigative research",
      "Election-cycle reporting",
      "Source development",
      "Crisis & safeguarding awareness",
    ],
  },
  {
    title: "Digital & Strategy",
    skills: [
      "Multi-platform storytelling",
      "Digital & social publishing strategy",
      "Multi-project coordination",
      "Deadline-driven delivery",
    ],
  },
];

export const education = [
  {
    school: "Institute of Management and Technology, Enugu",
    credential: "HND, Mass Communication",
    year: "2018",
  },
  {
    school: "Institute of Management and Technology, Enugu",
    credential: "ND, Mass Communication",
    year: "2012",
  },
];

export const certifications = [
  {
    name: "Broadcast Ethics & News Report Production",
    issuer: "BBC Media Action",
    year: "2014",
  },
  {
    name: "Change Begins With You — Gender-Based Violence",
    issuer: "Voice4Change (V4C)",
    year: "2016",
  },
];
