# Michael Ngene — Broadcast Portfolio

A production-ready personal portfolio for Michael Ngene, a broadcast
journalist and scriptwriter with newsroom experience spanning BBC News,
News Central Television, and radio stations across Nigeria.

## Concept

The site is built around a "newsroom rundown" visual language rather than a
generic SaaS-style template:

- **Studio theme** (default): a dark, broadcast-control-room palette with a
  tally-light red accent and a pulsing "on air" indicator.
- **Print Edition theme** (toggle in the nav): a light, newsprint-inspired
  palette using the same red accent, for a "printed edition" reading mode.
- **Typography**: Fraunces (serif display) for editorial authority, Space
  Grotesk for body/UI text, and JetBrains Mono for timecodes and small
  numeric labels — a nod to broadcast lower-thirds and rundown sheets.
- **Structure**: the Experience section is laid out as a rundown (period,
  duration, role) and Featured Work is presented as numbered "segments,"
  both genuine sequences rather than decorative numbering.

All copy was rewritten from Michael's CV and LinkedIn profile — nothing is
copied verbatim — and organized into `lib/data.ts` as a single source of
truth so content can be updated without touching component code.

## Tech stack

- [Next.js 14](https://nextjs.org/) (App Router)
- React 18 + TypeScript
- Tailwind CSS (custom design tokens, no UI kit)
- No external services, APIs, or environment variables required

## Project structure

```
app/
  layout.tsx        Root layout, fonts, metadata
  page.tsx           Assembles all page sections
  globals.css         Theme variables (Studio / Print Edition) + base styles
components/
  Nav.tsx             Fixed nav + theme toggle
  Hero.tsx            Headline, tagline, key stats
  About.tsx           Bio, education, certifications
  FeaturedWork.tsx     Top 3 career highlights ("segments")
  Experience.tsx       Full career rundown
  Skills.tsx           Skills grouped by category
  Contact.tsx          Contact links
  Footer.tsx
  ThemeProvider.tsx    Studio/Print Edition theme context (localStorage-backed)
lib/
  data.ts             All site content (single source of truth)
```

## Local setup

Requires Node.js 18.17 or later.

```bash
npm install
npm run dev
```

Then open [http://localhost:3000](http://localhost:3000).

To produce an optimized production build:

```bash
npm run build
npm run start
```

## Updating content

All text, dates, and links live in `lib/data.ts`. Update the `profile`,
`about`, `experience`, `projects`, `skillGroups`, `education`, and
`certifications` exports there — the components will pick up the changes
automatically.

Two dates were reconciled between the CV and LinkedIn profile where they
disagreed slightly (Ogene FM's end date and Dream FM's start date); the more
specific of the two sources was used. Double-check these against your own
records before publishing.

No fabricated performance metrics (view counts, audience growth
percentages, etc.) were added — only facts stated in the source documents
are presented as figures. If you have real numbers to add, drop them into
the relevant `bullets` or `stats` entries in `lib/data.ts`.
