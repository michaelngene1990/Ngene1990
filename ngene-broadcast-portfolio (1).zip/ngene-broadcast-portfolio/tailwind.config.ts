import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        studio: {
          DEFAULT: "#0E1013",
          surface: "#171A1F",
          line: "#2B2F36",
        },
        paper: {
          DEFAULT: "#F3F2EE",
          surface: "#FFFFFF",
          line: "#D8D6CF",
        },
        ink: {
          DEFAULT: "#F2F0EB",
          soft: "#A6ACB5",
        },
        press: {
          DEFAULT: "#14171B",
          soft: "#5B6067",
        },
        tally: {
          red: "#E24030",
          green: "#3AAE79",
        },
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "Georgia", "serif"],
        sans: ["var(--font-grotesk)", "Helvetica", "Arial", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "SFMono-Regular", "monospace"],
      },
      maxWidth: {
        content: "72rem",
      },
      keyframes: {
        tallypulse: {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.35" },
        },
        rollin: {
          "0%": { transform: "translateY(110%)" },
          "100%": { transform: "translateY(0%)" },
        },
        fadein: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
      },
      animation: {
        tallypulse: "tallypulse 1.8s ease-in-out infinite",
        rollin: "rollin 0.7s cubic-bezier(0.16, 1, 0.3, 1) forwards",
        fadein: "fadein 0.6s ease-out forwards",
      },
    },
  },
  plugins: [],
};

export default config;
