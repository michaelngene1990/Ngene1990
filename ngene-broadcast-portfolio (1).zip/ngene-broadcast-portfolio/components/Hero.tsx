import { profile, stats } from "@/lib/data";

const headlineLines = ["I turn the day's chaos", "into a script the", "newsroom can broadcast."];

export default function Hero() {
  return (
    <section
      id="top"
      className="flex min-h-screen flex-col justify-center px-6 pt-24"
    >
      <div className="mx-auto w-full max-w-content">
        <div
          className="mb-8 inline-flex items-center gap-2 rounded-full border px-3 py-1 font-mono text-xs uppercase tracking-[0.2em]"
          style={{ borderColor: "var(--line)", color: "var(--text-soft)" }}
        >
          <span
            className="h-1.5 w-1.5 rounded-full animate-tallypulse"
            style={{ backgroundColor: "var(--accent)" }}
          />
          On air &mdash; {profile.currentEmployer}, Lagos
        </div>

        <h1 className="font-display text-[13vw] leading-[0.98] tracking-tight sm:text-6xl md:text-7xl lg:text-8xl">
          {headlineLines.map((line, i) => (
            <span key={line} className="block overflow-hidden">
              <span
                className="block animate-rollin"
                style={{ animationDelay: `${i * 0.12 + 0.1}s` }}
              >
                {line}
              </span>
            </span>
          ))}
        </h1>

        <p
          className="mt-8 max-w-xl text-lg"
          style={{ color: "var(--text-soft)" }}
        >
          {profile.fullName} — Broadcast Scriptwriter &amp; Content Producer,
          {" "}{profile.location}. Ten years of writing news that survives
          contact with a live broadcast.
        </p>

        <div className="mt-10 flex flex-wrap items-center gap-4">
          <a
            href="#work"
            className="rounded-full px-6 py-3 text-sm font-medium transition-transform hover:-translate-y-0.5"
            style={{ backgroundColor: "var(--accent)", color: "#F8F5F0" }}
          >
            See the segments
          </a>
          <a
            href="#contact"
            className="rounded-full border px-6 py-3 text-sm font-medium transition-colors hover:text-[var(--accent)]"
            style={{ borderColor: "var(--line)" }}
          >
            Get in touch
          </a>
        </div>

        <dl className="mt-20 grid grid-cols-2 gap-x-8 gap-y-8 border-t pt-8 sm:grid-cols-4" style={{ borderColor: "var(--line)" }}>
          {stats.map((stat) => (
            <div key={stat.label}>
              <dt className="font-mono text-3xl">{stat.value}</dt>
              <dd className="mt-1 text-sm" style={{ color: "var(--text-soft)" }}>
                {stat.label}
              </dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
