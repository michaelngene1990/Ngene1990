import { experience } from "@/lib/data";

export default function Experience() {
  return (
    <section id="experience" className="px-6 py-28">
      <div className="mx-auto max-w-content">
        <span className="font-mono text-xs uppercase tracking-[0.2em]" style={{ color: "var(--accent)" }}>
          Experience
        </span>
        <h2 className="mt-4 max-w-2xl font-display text-4xl leading-tight md:text-5xl">
          The rundown, ten years long.
        </h2>

        <div className="mt-14">
          {experience.map((job) => (
            <div
              key={job.id}
              className="rundown-row grid gap-4 py-10 md:grid-cols-[200px_1fr]"
            >
              <div>
                <div className="flex items-center gap-2 font-mono text-xs tracking-wider" style={{ color: "var(--text-soft)" }}>
                  {job.current && (
                    <span
                      className="h-1.5 w-1.5 rounded-full animate-tallypulse"
                      style={{ backgroundColor: "var(--accent-soft)" }}
                    />
                  )}
                  {job.period}
                </div>
                <p className="mt-1 font-mono text-xs" style={{ color: "var(--text-soft)" }}>
                  {job.duration}
                </p>
              </div>

              <div>
                <h3 className="font-display text-2xl">{job.role}</h3>
                <p className="mt-1 text-sm" style={{ color: "var(--accent)" }}>
                  {job.org} &middot; {job.location}
                </p>
                <p className="mt-4 max-w-2xl text-base leading-relaxed" style={{ color: "var(--text-soft)" }}>
                  {job.summary}
                </p>
                <ul className="mt-4 space-y-2">
                  {job.bullets.map((bullet) => (
                    <li
                      key={bullet.slice(0, 24)}
                      className="flex gap-3 text-sm leading-relaxed"
                      style={{ color: "var(--text-soft)" }}
                    >
                      <span className="mt-2 h-1 w-1 shrink-0 rounded-full" style={{ backgroundColor: "var(--line)" }} />
                      {bullet}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
