import { about, education, certifications } from "@/lib/data";

const bars = [
  18, 32, 24, 48, 30, 60, 40, 72, 50, 88, 62, 96, 70, 88, 58, 74, 44, 62, 30,
  48, 22, 36, 16, 26,
];

function Waveform() {
  return (
    <svg
      viewBox="0 0 340 120"
      className="h-auto w-full max-w-xs"
      role="img"
      aria-label="Stylised broadcast audio waveform"
    >
      {bars.map((h, i) => (
        <rect
          key={i}
          x={i * 14}
          y={60 - h / 2}
          width={6}
          height={h}
          rx={3}
          fill={i % 5 === 0 ? "var(--accent)" : "var(--line)"}
        />
      ))}
    </svg>
  );
}

export default function About() {
  return (
    <section id="about" className="px-6 py-28">
      <div className="mx-auto grid max-w-content gap-14 md:grid-cols-[1.1fr_0.9fr]">
        <div>
          <span
            className="font-mono text-xs uppercase tracking-[0.2em]"
            style={{ color: "var(--accent)" }}
          >
            About
          </span>
          <h2 className="mt-4 font-display text-4xl leading-tight md:text-5xl">
            From the mic in Enugu to the rundown at BBC News.
          </h2>

          <div className="mt-8 space-y-5 text-base leading-relaxed md:text-lg" style={{ color: "var(--text-soft)" }}>
            {about.paragraphs.map((p) => (
              <p key={p.slice(0, 24)}>{p}</p>
            ))}
          </div>
        </div>

        <div className="flex flex-col justify-between gap-10">
          <div
            className="flex items-center justify-center rounded-2xl border p-8"
            style={{ borderColor: "var(--line)", backgroundColor: "var(--surface)" }}
          >
            <Waveform />
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="font-mono text-xs uppercase tracking-[0.2em]" style={{ color: "var(--text-soft)" }}>
                Education
              </h3>
              <ul className="mt-3 space-y-2">
                {education.map((e) => (
                  <li key={e.credential} className="flex justify-between gap-4 text-sm">
                    <span>{e.credential}, {e.school}</span>
                    <span className="font-mono" style={{ color: "var(--text-soft)" }}>{e.year}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-mono text-xs uppercase tracking-[0.2em]" style={{ color: "var(--text-soft)" }}>
                Certifications
              </h3>
              <ul className="mt-3 space-y-2">
                {certifications.map((c) => (
                  <li key={c.name} className="flex justify-between gap-4 text-sm">
                    <span>{c.name} — {c.issuer}</span>
                    <span className="font-mono" style={{ color: "var(--text-soft)" }}>{c.year}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
