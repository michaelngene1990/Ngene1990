"use client";

import { useTheme } from "./ThemeProvider";

const links = [
  { href: "#about", label: "About" },
  { href: "#work", label: "Featured Work" },
  { href: "#experience", label: "Experience" },
  { href: "#skills", label: "Skills" },
  { href: "#contact", label: "Contact" },
];

export default function Nav() {
  const { theme, toggle } = useTheme();

  return (
    <header
      className="fixed top-0 z-50 w-full backdrop-blur"
      style={{
        backgroundColor: "rgba(var(--bg-rgb), 0.82)",
        borderBottom: "1px solid var(--line)",
      }}
    >
      <nav className="mx-auto flex max-w-content items-center justify-between px-6 py-4">
        <a href="#top" className="font-display text-lg tracking-tight">
          Michael Ngene
        </a>

        <ul
          className="hidden gap-7 text-sm md:flex"
          style={{ color: "var(--text-soft)" }}
        >
          {links.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="transition-colors hover:text-[var(--text)]"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <button
          onClick={toggle}
          aria-label="Toggle between Studio and Print Edition themes"
          className="flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-mono uppercase tracking-wider transition-colors"
          style={{ borderColor: "var(--line)", color: "var(--text-soft)" }}
        >
          <span
            className="h-1.5 w-1.5 rounded-full animate-tallypulse"
            style={{ backgroundColor: "var(--accent)" }}
          />
          {theme === "studio" ? "Studio" : "Print Edition"}
        </button>
      </nav>
    </header>
  );
}
