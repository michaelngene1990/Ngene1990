import { skillGroups } from "@/lib/data";

export default function Skills() {
  return (
    <section id="skills" className="px-6 py-28" style={{ backgroundColor: "var(--surface)" }}>
      <div className="mx-auto max-w-content">
        <span className="font-mono text-xs uppercase tracking-[0.2em]" style={{ color: "var(--accent)" }}>
          Skills
        </span>
        <h2 className="mt-4 max-w-2xl font-display text-4xl leading-tight md:text-5xl">
          What's on the desk.
        </h2>

        <div className="mt-14 grid gap-x-10 gap-y-12 sm:grid-cols-2">
          {skillGroups.map((group) => (
            <div key={group.title}>
              <h3 className="font-display text-xl">{group.title}</h3>
              <ul className="mt-4 space-y-3 border-t pt-4" style={{ borderColor: "var(--line)" }}>
                {group.skills.map((skill) => (
                  <li
                    key={skill}
                    className="flex items-center justify-between text-sm"
                    style={{ color: "var(--text-soft)" }}
                  >
                    {skill}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
