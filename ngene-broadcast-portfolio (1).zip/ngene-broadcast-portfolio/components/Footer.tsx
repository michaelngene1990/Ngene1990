import { profile } from "@/lib/data";

export default function Footer() {
  return (
    <footer
      className="px-6 py-10"
      style={{ borderTop: "1px solid var(--line)" }}
    >
      <div
        className="mx-auto flex max-w-content flex-col items-center justify-between gap-3 text-xs font-mono uppercase tracking-wider sm:flex-row"
        style={{ color: "var(--text-soft)" }}
      >
        <span>&copy; {new Date().getFullYear()} {profile.name}</span>
        <span>{profile.location}</span>
      </div>
    </footer>
  );
}
