import { profile } from "@/lib/data";

export default function Contact() {
  return (
    <section id="contact" className="px-6 py-28">
      <div className="mx-auto max-w-content">
        <span className="font-mono text-xs uppercase tracking-[0.2em]" style={{ color: "var(--accent)" }}>
          Contact
        </span>
        <h2 className="mt-4 max-w-2xl font-display text-4xl leading-tight md:text-5xl">
          Have a newsroom seat open?
        </h2>
        <p className="mt-6 max-w-xl text-lg" style={{ color: "var(--text-soft)" }}>
          Based in {profile.location}, available for broadcast, digital, and
          production roles &mdash; and open to a conversation either way.
        </p>

        <div className="mt-10 flex flex-col gap-4 sm:flex-row sm:items-center sm:gap-8">
          <a
            href={`mailto:${profile.email}`}
            className="rounded-full px-6 py-3 text-center text-sm font-medium"
            style={{ backgroundColor: "var(--accent)", color: "#F8F5F0" }}
          >
            {profile.email}
          </a>
          <a
            href={`tel:${profile.phone.replace(/\s/g, "")}`}
            className="font-mono text-sm transition-colors hover:text-[var(--accent)]"
            style={{ color: "var(--text-soft)" }}
          >
            {profile.phone}
          </a>
          <a
            href={profile.linkedin}
            target="_blank"
            rel="noreferrer"
            className="font-mono text-sm transition-colors hover:text-[var(--accent)]"
            style={{ color: "var(--text-soft)" }}
          >
            linkedin.com/in/michaelngene90
          </a>
        </div>
      </div>
    </section>
  );
}
