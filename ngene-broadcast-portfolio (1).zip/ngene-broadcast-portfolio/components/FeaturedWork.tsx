import { projects } from "@/lib/data";

export default function FeaturedWork() {
  return (
    <section id="work" className="px-6 py-28" style={{ backgroundColor: "var(--surface)" }}>
      <div className="mx-auto max-w-content">
        <span className="font-mono text-xs uppercase tracking-[0.2em]" style={{ color: "var(--accent)" }}>
          Featured Work
        </span>
        <h2 className="mt-4 max-w-2xl font-display text-4xl leading-tight md:text-5xl">
          Three segments that moved past the studio.
        </h2>

        <div className="mt-14 border-t" style={{ borderColor: "var(--line)" }}>
          {projects.map((project) => (
            <article
              key={project.id}
              className="group grid gap-4 border-b py-10 transition-colors md:grid-cols-[220px_1fr]"
              style={{ borderColor: "var(--line)" }}
            >
              <div>
                <span className="font-mono text-xs tracking-[0.2em]" style={{ color: "var(--accent)" }}>
                  {project.tag}
                </span>
                <p className="mt-2 text-sm" style={{ color: "var(--text-soft)" }}>
                  {project.outlet}
                </p>
              </div>

              <div>
                <h3 className="font-display text-2xl transition-transform duration-300 group-hover:translate-x-2 md:text-3xl">
                  {project.title}
                </h3>
                <p className="mt-3 max-w-2xl text-base leading-relaxed" style={{ color: "var(--text-soft)" }}>
                  {project.description}
                </p>
                <p className="mt-3 max-w-2xl text-sm leading-relaxed" style={{ color: "var(--text-soft)" }}>
                  {project.detail}
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
